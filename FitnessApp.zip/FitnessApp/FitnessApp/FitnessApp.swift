//
//  FitnessApp.swift
//  FitnessApp
//
//  Created by Hannah Amaria Naidoo on 2023/10/26.
//

import SwiftUI

@main struct FitnessApp: App {
    
    @AppStorage("isLightMode") var isLightMode = false
    
    var body: some Scene {
        WindowGroup {
            SplashScreen()
                .preferredColorScheme(isLightMode ? .light : .dark)
        }
    }
}
