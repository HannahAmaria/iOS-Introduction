//
//  Settings.swift
//  FitnessApp
//
//  Created by Hannah Amaria Naidoo on 2023/10/26.
//

import SwiftUI

struct Settings: View {
    var body: some View {
        ZStack{
            Circle()
                .frame(width: 50, height: 50)
                .foregroundColor(Color("White"))
                .shadow(radius: 4)
            Image(systemName: "gear")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 30, height: 30)
                .foregroundColor(Color("Black"))
        }
    }
}

struct Settings_Previews: PreviewProvider {
    static var previews: some View {
        Settings()
    }
}
