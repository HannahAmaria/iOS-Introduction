//
//  OnboardingSlider.swift
//  FitnessApp
//
//  Created by Hannah Amaria Naidoo on 2023/10/26.
//

import SwiftUI

struct OnboardingSlider: View {
    
    var onboard: Onboarding
    
    var body: some View {
        Image(onboard.Image)
            .resizable()
            .scaledToFill()
            .edgesIgnoringSafeArea(.top)
        
        VStack{
            Text(onboard.description)
                .padding(.top, 400)
                .padding(.leading, 70)
                .padding(.trailing, 70)
                .font(.system(size: 20, weight: .regular, design: .default))
                .multilineTextAlignment(.center)
                .foregroundColor(Color("Black"))
        }
    }
}

struct OnboardingSlider_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingSlider(onboard: OnboardingData[0])
    }
}
