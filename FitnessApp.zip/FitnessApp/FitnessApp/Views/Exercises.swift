//
//  Exercises.swift
//  FitnessApp
//
//  Created by Hannah Amaria Naidoo on 2023/10/26.
//

import SwiftUI

struct Exercises: View {
    
    var title : String
    var info : String
    
    var body: some View {
        VStack(alignment: .leading){
            Text(title)
                .font(.system(size: 22, weight: .semibold, design: .default))
            
            Text(info)
                .font(.system(size: 20, weight: .regular, design: .default))
        }
        .padding(.bottom, 1)
    }
}

struct Exercises_Previews: PreviewProvider {
    static var previews: some View {
        Exercises(title: "Equipment", info: "Yoga mat")
    }
}
