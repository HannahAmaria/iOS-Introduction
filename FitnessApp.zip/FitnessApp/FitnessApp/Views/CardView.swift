//
//  CardView.swift
//  FitnessApp
//
//  Created by Hannah Amaria Naidoo on 2023/10/26.
//

import SwiftUI

struct CardView: View {
    var poses: Fitness

    var body: some View {
        VStack {
            VStack {
                Image(poses.Image)
                    .resizable()
                    .frame(width: 100, height: 100)
                    .foregroundColor(Color("Black"))
                    .padding(.top, -20)

                Text(poses.Name)
                    .lineLimit(1)
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundColor(Color("Black"))

                Text(poses.Benefits)
                    .lineLimit(1)
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(Color("Black"))
                    .padding(.bottom, 2)

                Text(poses.description)
                    .lineLimit(3)
                    .font(.system(size: 15, weight: .thin))
                    .foregroundColor(Color("Black"))
            }
            .padding(20)
        }
        .padding(.bottom, 10)
    }
}

struct CardView_Previews: PreviewProvider {
    static var previews: some View {
        CardView(poses: FitnessData[0])
    }
}
