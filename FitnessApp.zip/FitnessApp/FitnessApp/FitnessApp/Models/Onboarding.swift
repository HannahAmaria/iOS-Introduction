//
//  Onboarding.swift
//  FitnessApp
//
//  Created by Hannah Amaria Naidoo on 2023/10/26.
//

import SwiftUI

struct Onboarding: Identifiable {
    let id = UUID().uuidString
    let Image : String
    let description : String
}
