//
//  Fitness.swift
//  FitnessApp
//
//  Created by Hannah Amaria Naidoo on 2023/10/26.
//

import Foundation

struct Fitness: Identifiable {
    var id = UUID()
    var Image: String
    var Name: String
    var Color: String
    var duration: String
    var Focus: String
    var Equipment: String
    var Benefits: String
    var description: String
}
