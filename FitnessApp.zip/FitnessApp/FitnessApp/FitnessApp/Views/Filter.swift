//
//  Filter.swift
//  FitnessApp
//
//  Created by Hannah Amaria Naidoo on 2023/10/26.
//

import SwiftUI

struct Filter: View {
    
    var FilterOption : String
    
    var body: some View {
        
        ZStack{
            Capsule()
                .frame(width: 100, height: 40)
                
            Text(FilterOption)
                .foregroundColor(.white)
        }
        
    }
}

struct Filter_Previews: PreviewProvider {
    static var previews: some View {
        Filter(FilterOption: "Filter")
    }
}
