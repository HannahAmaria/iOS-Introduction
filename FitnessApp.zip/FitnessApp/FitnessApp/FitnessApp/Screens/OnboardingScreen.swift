//
//  OnboardingScreen.swift
//  FitnessApp
//
//  Created by Hannah Amaria Naidoo on 2023/10/26.
//

import SwiftUI

struct OnboardingScreen: View {
    
    @AppStorage("onboardingComplete") var onboardingComplete = false

    var onboarding: [Onboarding] = OnboardingData
    @State private var currentLocation = 0
    

    var body: some View {
        VStack{
            TabView(){
                ForEach(onboarding){ onboard in
                    ZStack{
                        OnboardingSlider(onboard: onboard)
                    }
                } 
            }
            .ignoresSafeArea()
            .tabViewStyle(.page(indexDisplayMode: .always))
            .indexViewStyle(.page(backgroundDisplayMode: .always))
            Spacer()
            
            Button {
                onboardingComplete = true
            } label: {
                Text("Start")
                    .foregroundColor(.white)
                    .frame(width: 340 , height: 35, alignment: .center)
                    .font(.system(size: 18, weight: .bold, design: .default))
                    .padding(7)
            }
            .background(Color.black)
            .clipShape(Capsule())
        }
        
    }
}

struct OnboardingScreen_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingScreen()
    }
}
