//
//  DetailedView.swift
//  FitnessApp
//
//  Created by Hannah Amaria Naidoo on 2023/10/26.
//

import SwiftUI

struct DetailedView: View {
    var poses: Fitness
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(poses.Name)
                .font(.system(size: 32, weight: .bold, design: .default))
                .foregroundColor(Color("Black"))
                .padding(.horizontal, 20)
                .padding(.top, 20)
            
            ScrollView(.vertical) {
                VStack(alignment: .leading) {
                    Image(poses.Image)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 300, height: 300)
                        .padding(.horizontal, 50)
                    
                    VStack(alignment: .leading, spacing: 20) {
                        Exercises(title: "Duration: ", info: poses.duration)
                        Exercises(title: "Equipment: ", info: poses.Equipment)
                        Exercises(title: "Focus: ", info: poses.Focus)
                        Exercises(title: "Benefits: ", info: poses.Benefits)
                    }
                    .padding(.horizontal, 20)
                    
                    Divider()
                    
                    Text(poses.description)
                        .font(.system(size: 15, weight: .regular, design: .default))
                        .padding(.horizontal, 20)
                        .padding(.top, 10)
                }
            }
        }
    }
}

struct DetailedView_Previews: PreviewProvider {
    static var previews: some View {
        DetailedView(poses: FitnessData.first!)
    }
}
