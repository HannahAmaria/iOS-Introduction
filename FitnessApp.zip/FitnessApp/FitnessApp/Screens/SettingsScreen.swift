//
//  SettingsScreen.swift
//  FitnessApp
//
//  Created by Hannah Amaria Naidoo on 2023/10/26.
//

import SwiftUI

struct SettingsScreen: View {
    
    @State var showAbout: Bool = false
    @State private var searchText = ""
    
    @AppStorage("isLightMode") var isLightMode = false
    
    var body: some View {
        VStack(alignment: .leading){
            Text("Settings")
                .font(.system(size: 32, weight: .bold, design: .default))
                .foregroundColor(Color("Black"))
                .padding(.top)
            
            Divider()
                .padding(.bottom)
            
            ScrollView(.vertical){
                GroupBox{
                    VStack{
                        Text("Theme")
                            .font(.system(size: 20, weight: .semibold, design: .default))
                            .foregroundColor(Color("Black"))
                                        
                        Picker("Mode", selection: $isLightMode){
                            Text("Light").tag(true)
                            Text("Dark").tag(false)
                        }
                        .pickerStyle(SegmentedPickerStyle())
                        .padding(.top)
                    }
                    .padding(.top, 1)
                    .padding(.bottom, 1)
                    .padding(.horizontal, 20)
                }
                
                GroupBox{
                    DisclosureGroup("About Fitness Pro", isExpanded: $showAbout){
                        Text("Designed for today's active lifestyle, Fitness Pro is a comprehensive wellness hub tailored to meet your health goals. With an intuitive interface and an array of workout routines, our app is your ultimate fitness companion.")
                            .multilineTextAlignment(.center)
                            .padding(.top, 10)
                            .padding(.bottom, 10)
                        
                        Text("Version 4.0")
                            .font(.system(size: 20, weight: .semibold, design: .default))
                    }
                }
                .padding(.bottom, 10)
            }
            
            Spacer()
            
            Link(destination: URL(string: "https://github.com/HannahAmaria/iOS-Introduction")!, label: {
                HStack{
                    Image("GitHubLogo")
                        .resizable()
                        .frame(width: 25, height: 25)
                        .padding(.trailing, 20)
                    
                    Text("GitHub")
                        .foregroundColor(.white)
                        .font(.system(size: 18, weight: .bold, design: .default))
                }
            })
            .frame(width: 340, height: 35)
            .padding(7)
            .background(Color.black)
            .clipShape(Capsule())
        }
        .padding(.horizontal, 30)
    }
}

struct SettingsScreen_Previews: PreviewProvider {
    static var previews: some View {
        SettingsScreen()
    }
}
