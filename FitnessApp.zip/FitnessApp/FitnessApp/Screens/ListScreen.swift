//
//  ListScreen.swift
//  FitnessApp
//
//  Created by Hannah Amaria Naidoo on 2023/10/26.
//

import SwiftUI

struct ListScreen: View {
    @State var exercise: [Fitness] = FitnessData
    
    private let adaptiveColomns = [
        GridItem(.adaptive(minimum: 163))
    ]
    
    @State var text = ""
    
    var filteredPoses: [Fitness]{
        if (text.isEmpty) {
            return FitnessData
        } else {
            return FitnessData.filter { $0.Name.contains(text) }
        }
    }
    
    var body: some View {
        NavigationView{
            VStack{
                HStack{
                    Text("Fitness App")
                        .padding(.top)
                        .font(.system(size: 32, weight: .bold, design: .default))
                        .foregroundColor(Color("Black"))

                    Spacer()

                    NavigationLink(destination: SettingsScreen(), label: {
                        Settings()
                    })
                }
                .padding(.horizontal, 20)
                
                ScrollView(.vertical, showsIndicators: false){
                    SearchBar(text: $text)
                        .padding(.bottom, 20)
                    LazyVGrid(columns: adaptiveColomns, spacing: 20){
                        ForEach(text.isEmpty ? exercise : filteredPoses){ exercise in
                            NavigationLink(destination: DetailedView(poses: exercise), label: {
                                CardView(poses: exercise)
                            })
                        }
                    }
                }
                .padding(.horizontal, 20)

            }
        }
    }
}

struct ListScreen_Previews: PreviewProvider {
    static var previews: some View {
        ListScreen()
    }
}

//TODO: Category filter
