//
//  OnboardingData.swift
//  FitnessApp
//
//  Created by Hannah Amaria Naidoo on 2023/10/26.
//

import SwiftUI

let OnboardingData : [Onboarding] = [

    Onboarding(Image: "Onboarding1", description: "Welcome to Fitness Pro!"),
    
    Onboarding(Image: "Onboarding2", description: "Get your daily workouts!"),
    
    Onboarding(Image: "Onboarding3", description: "Be healthy and live longer!")

]
