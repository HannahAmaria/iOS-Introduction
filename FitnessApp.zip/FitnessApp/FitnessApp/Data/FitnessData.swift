//
//  FitnessData.swift
//  FitnessApp
//
//  Created by Hannah Amaria Naidoo on 2023/10/26.
//

import SwiftUI

let FitnessData: [Fitness] = [
    
    Fitness (Image: "DancerPose",
            Name: "Dancer Pose",
            Color: "White",
            duration: "Hold for 60 seconds",
            Focus: "Feet, ankles, legs, core, back and arms",
            Equipment: "Dancer pose strap",
            Benefits: "Dancer Pose improves balance and focus, posture, postural awareness and body awareness. It can boost energy and fight fatigue, and help build confidence and empowerment.",
            description: "Dancer Pose is a deep backbend that requires patience, focus, and persistence. The pose is named after the Hindu god Shiva Nataraja, King of the Dance, who finds bliss in the midst of destruction. Like its namesake, Lord of the Dance Pose embodies finding steadying calm within."),
    
    Fitness (Image: "Triangle",
            Name: "Triangle",
            Color: "White",
            duration: "Hold for 30 seconds",
            Focus: "Hamstrings, groins, glutes, hips and ankles",
            Equipment: "Yoga mat",
            Benefits: "The Triangle Pose is a standing posture with multiple benefits. It stretches and strengthens the legs, hips, and torso, enhancing flexibility in these areas while promoting better posture and spinal alignment. This pose aids in digestion, relieves stress, and strengthens the core muscles. It also stimulates circulation, providing an energizing effect and mental clarity. Practicing the Triangle Pose regularly can revitalize the body, offering a holistic approach to physical and mental well-being.",
            description: "The triangle pose is not a forward bend but a sideways movement at the hips performed with straight arms and legs. Avoid bending your back and rounding your spine while performing a triangle pose."),
    
    Fitness (Image: "HighCresentLunge",
            Name: "High Cresent Lunge",
            Color: "White",
            duration: "Hold for 30 seconds",
            Focus: "Thighs, hips, glutes, core and shoulders.",
            Equipment: "Yoga mat",
            Benefits: "The High Crescent Lunge is a strengthening and stretching posture that engages the lower body, enhancing leg strength and flexibility. This pose helps to tone the thighs, hamstrings, and glutes, while stretching the hip flexors and quadriceps. It promotes balance, stability, and core strength, also aiding in opening the chest and shoulders for improved posture. Alongside physical benefits, the High Crescent Lunge encourages mental focus, reducing stress and enhancing concentration, making it a comprehensive pose for both physical and mental well-being.",
            description: "The High Crescent Lunge is a yoga pose where one foot is positioned forward in a deep lunge while the other extends behind. It emphasizes lower body strength, enhancing the legs while stretching hip flexors. This posture encourages balance, stability, and mental focus."),
    
    Fitness (Image: "TwistedBoat",
            Name: "Twisted Boat",
            Color: "White",
            duration: "Hold for 20 seconds",
            Focus: "Core muscles",
            Equipment: "Yoga mat",
            Benefits: "The Twisted Boat pose engages all aspects of your core muscles without overworking them. Your core muscles help maintain the pose in good form, strengthening them over time. Arms and legs. The boat pose exercise also engages your arms and legs, specifically your upper arms (biceps and triceps) and hamstrings.",
            description: "Start in Twisted oat Pose and roll onto your right hip with your knees to the right. Reach your arms over to the left. Lower to hover your legs and chest off the mat, then crunch up to Twisted Boat Pose. Lower to hover and repeat.")

]

func filterByColor(color: String) -> [Fitness]{
    var poses: [Fitness] = []
    
    if(color == "White"){
        
        poses.append(Fitness (Image: "DancerPose",
                             Name: "Dancer Pose",
                             Color: "White",
                             duration: "Hold for 60 seconds",
                             Focus: "Feet, ankles, legs, core, back and arms",
                             Equipment: "Dancer pose strap",
                             Benefits: "Dancer Pose improves balance and focus, posture, postural awareness and body awareness. It can boost energy and fight fatigue, and help build confidence and empowerment.",
                             description: "Dancer Pose is a deep backbend that requires patience, focus, and persistence. The pose is named after the Hindu god Shiva Nataraja, King of the Dance, who finds bliss in the midst of destruction. Like its namesake, Lord of the Dance Pose embodies finding steadying calm within.")
        )
        poses.append(Fitness (Image: "Triangle",
                              Name: "Triangle",
                              Color: "White",
                              duration: "Hold for 30 seconds",
                              Focus: "Hamstrings, groins, glutes, hips, and ankles",
                              Equipment: "Yoga mat",
                              Benefits: "The Triangle Pose is a dynamic standing posture with multiple benefits. It stretches and strengthens the legs, hips, and torso, enhancing flexibility in these areas while promoting better posture and spinal alignment. This pose aids in digestion, relieves stress, and strengthens the core muscles. It also stimulates circulation, providing an energizing effect and mental clarity. Practicing the Triangle Pose regularly can revitalize the body, offering a holistic approach to physical and mental well-being.",
                              description: "The triangle pose is not a forward bend but a sideways movement at the hips performed with straight arms and legs. Avoid bending your back and rounding your spine while performing a triangle pose.")
        )
        
    } else if (color == "White"){
        poses.append(Fitness (Image: "HighCresentLunge",
                             Name: "High Cresent Lunge",
                             Color: "White",
                             duration: "Hold for 30 seconds",
                             Focus: "Thighs, hips, glutes, core and shoulders.",
                             Equipment: "Yoga mat",
                             Benefits: "The High Crescent Lunge is a strengthening and stretching posture that engages the lower body, enhancing leg strength and flexibility. This pose helps to tone the thighs, hamstrings, and glutes, while stretching the hip flexors and quadriceps. It promotes balance, stability, and core strength, also aiding in opening the chest and shoulders for improved posture. Alongside physical benefits, the High Crescent Lunge encourages mental focus, reducing stress and enhancing concentration, making it a comprehensive pose for both physical and mental well-being.",
                             description: "The High Crescent Lunge is a yoga pose where one foot is positioned forward in a deep lunge while the other extends behind. It emphasizes lower body strength, enhancing the legs while stretching hip flexors. This posture encourages balance, stability, and mental focus.")
        )
    } else if (color == "White") {
        poses.append(Fitness (Image: "TwistedBoat",
                              Name: "Twisted Boat",
                              Color: "White",
                              duration: "Hold for 20 seconds",
                              Focus: "Core muscles",
                              Equipment: "Yoga mat",
                              Benefits: "The Twisted Boat pose engages all aspects of your core muscles without overworking them. Your core muscles help maintain the pose in good form, strengthening them over time. Arms and legs. The boat pose exercise also engages your arms and legs, specifically your upper arms (biceps and triceps) and hamstrings.",
                              description: "Start in Twisted oat Pose and roll onto your right hip with your knees to the right. Reach your arms over to the left. Lower to hover your legs and chest off the mat, then crunch up to Twisted Boat Pose. Lower to hover and repeat.")
        )
        
    } else {
        poses = FitnessData
    }
        
    return FitnessData
}
